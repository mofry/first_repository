#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>

// Fonction pour dessiner un cercle (approximation) au centre (cx, cy) avec un rayon r
void draw_circle(SDL_Renderer *renderer, int cx, int cy, int r) {
    const int segments = 360;
    for (int i = 0; i < segments; i++) {
        float theta1 = (2.0f * M_PI * i) / segments;
        float theta2 = (2.0f * M_PI * (i + 1)) / segments;

        int x1 = cx + (int)(r * cosf(theta1));
        int y1 = cy + (int)(r * sinf(theta1));
        int x2 = cx + (int)(r * cosf(theta2));
        int y2 = cy + (int)(r * sinf(theta2));

        SDL_RenderDrawLine(renderer, x1, y1, x2, y2);
    }
}

void draw_star(SDL_Renderer* renderer, int cx, int cy, float r) {
    const int branches = 5;
    const float pi = M_PI;
    SDL_Point points[11];

    for (int i = 0; i < 10; i++) {
        float angle = i * pi / 5.0f - pi / 2.0f;
        float radius = (i % 2 == 0) ? r : r / 2.5f;
        points[i].x = cx + (int)(radius * cosf(angle));
        points[i].y = cy + (int)(radius * sinf(angle));
    }
    points[10] = points[0]; // pour fermer l'étoile

    SDL_RenderDrawLines(renderer, points, 11);
}



bool rectangle_dans_cercle(int rect_x, int rect_y, int rect_w, int rect_h,
                           int cx, int cy, int r) {
    int sommets_r[4][2] = {
        {rect_x, rect_y},
        {rect_x + rect_w, rect_y},
        {rect_x, rect_y + rect_h},
        {rect_x + rect_w, rect_y + rect_h}
    };

    for (int i = 0; i < 4; i++) {
        int dx = sommets_r[i][0] - cx;
        int dy = sommets_r[i][1] - cy;
        float dist = sqrtf(dx * dx + dy * dy);
        if (dist > r) {
            return false; 
        }
    }
    return true;
}


int main(int argc, char* argv[]) {
    (void)argc; (void)argv;

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        printf("Erreur SDL_Init : %s\n", SDL_GetError());
        return 1;
    }

    SDL_Window* window = SDL_CreateWindow("SDL2 Formes et Animation",
                                          SDL_WINDOWPOS_CENTERED,
                                          SDL_WINDOWPOS_CENTERED,
                                          640, 480,
                                          SDL_WINDOW_SHOWN);
    if (!window) {
        printf("Erreur SDL_CreateWindow : %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1,
                            SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!renderer) {
        printf("Erreur SDL_CreateRenderer : %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    bool running = true;
    SDL_Event event;

    bool etoile_visible = false;
    

    float taille_etoile = 0.0;

    int rect_x = 0;
    int rect_y = 240-25;
    int rect_w = 100;
    int rect_h = 50;
    int speed_x = 3;

    int c_increment =0;

    while (running) {
        // Gestion des événements
        while (SDL_PollEvent(&event)) {


            SDL_Keycode key = event.key.keysym.sym;
            
            if ((event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE)||event.type == SDL_QUIT||rect_w*rect_h<400) {
                running = false;
            }
            if (event.type == SDL_KEYDOWN){
                if (key == SDLK_SPACE)
                    c_increment+=5;
            }
        }


        if (rectangle_dans_cercle(rect_x, rect_y, rect_w, rect_h, 320, 240, 30)){
            etoile_visible = true;
            if (taille_etoile<50.0) taille_etoile+=1.0;
            if (taille_etoile = 50.0) running = false;
        }
        else {
            rect_x += 2*speed_x;
            if (rect_x + rect_w > 640) {
                speed_x = -speed_x*1.25; 
                rect_w = rect_w * 3/4;
                rect_h = rect_h * 3/4;
                rect_x = 640-rect_w;
                rect_y = 240 - rect_h/2;

            }
            else if (rect_x < 0){
                speed_x = -speed_x*1.25;
                rect_w = rect_w * 3/4;
                rect_h = rect_h * 3/4;
                rect_x = 0;
                rect_y = 240 - rect_h/2;
            }
            
            if (c_increment>0){
                rect_y -=30;
                c_increment--;
            }
            if (rect_y>0) rect_y+=5;
            if (rect_y>480) running = false;
        }
        
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        if (etoile_visible) {
            SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255); 
            draw_star(renderer, 320, 240, taille_etoile);
        }

        
        SDL_Rect rect = {rect_x, rect_y, rect_w, rect_h};
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
        SDL_RenderFillRect(renderer, &rect);

        
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderDrawLine(renderer, 0, 0, 640, 480);
        SDL_RenderDrawLine(renderer, 0, 480, 640, 0);

        
        SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
        draw_circle(renderer, 320, 240, 30);

        
        SDL_RenderPresent(renderer);

        
        SDL_Delay(16);
    }

    
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
