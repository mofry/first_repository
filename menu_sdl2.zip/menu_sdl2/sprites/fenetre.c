#include <SDL2/SDL.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>



     void draw(SDL_Renderer* renderer) {                          
       SDL_Rect rectangle;                                                
                                            
       SDL_SetRenderDrawColor(renderer,                                       
                  50, 0, 0,                             // mode Red, Green, Blue (tous dans 0..255)
                  255);                                 // 0 = transparent ; 255 = opaque
       rectangle.x = 0;                                             // x haut gauche du rectangle
       rectangle.y = 0;                                                  // y haut gauche du rectangle
       rectangle.w = 400;                                                // sa largeur (w = width)
       rectangle.h = 400;                                                // sa hauteur (h = height)
                                            
       SDL_RenderFillRect(renderer, &rectangle);                        
                                            
       SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);                   
       SDL_RenderDrawLine(renderer,                             
              0, 0,                                          // x,y du point de la première extrémité
              400, 400);                                // x,y seconde extrémité
                                            

       /* tracer un cercle n'est en fait pas trivial, voilà le résultat sans algo intelligent ... */
       for (float angle = 0; angle < 2 * M_PI; angle += M_PI / 4000) {      
     SDL_SetRenderDrawColor(renderer,
                (cos(angle * 2) + 1) * 255 / 2,          // quantité de Rouge      
                (cos(angle * 5) + 1) * 255 / 2,          //          de vert 
                (cos(angle) + 1) * 255 / 2,              //          de bleu
                255);                                    // opacité = opaque
     SDL_RenderDrawPoint(renderer,                  
                 200 + 100 * cos(angle),                     // coordonnée en x
                 200 + 150 * sin(angle));                    //            en y   
       }
     }






int main(int argc, char **argv) {
    (void)argc;
    (void)argv;

    SDL_Window * window1 = NULL;
    SDL_Window * window2 = NULL;
    SDL_Renderer * renderer1 = NULL;
    




    if (SDL_Init(SDL_INIT_VIDEO) != 0){
        SDL_Log("Error : SDL initialisation - %s\n", SDL_GetError());
        exit(EXIT_FAILURE);
    }

    int x_ecran, y_ecran, x_window, y_window, x_init, y_init, pas;

    SDL_DisplayMode mode;
    SDL_GetCurrentDisplayMode(0, &mode);
    x_ecran = mode.w;
    y_ecran = mode.h;

    x_window = x_ecran/4;
    y_window = y_ecran/4;
    x_init = 0;
    y_init = 1;

    pas = 5;

    bool q = false,
         d = false,
         w = false,
         s = false;


    window1 = SDL_CreateWindow(
        "Fenêtre 1",
        x_init, y_init,
        x_window, y_window,
        SDL_WINDOW_RESIZABLE);

    if (window1 == NULL) {
        SDL_Log("Error : SDL window 1 creation - %s\n", 
        SDL_GetError());                 // échec de la création de la fenêtre
        SDL_Quit();                              // On referme la SDL       
        exit(EXIT_FAILURE);
    }


    renderer1 = SDL_CreateRenderer(window1, -1,
                SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

    if (!renderer1) {
        printf("Erreur création renderer : %s\n", SDL_GetError());
        SDL_DestroyWindow(window1);
        SDL_Quit();
        return 1;
    }


    SDL_bool 
        program_on = SDL_TRUE,                // Booléen pour dire que le programme doit continuer
        pause = SDL_FALSE,
        event_utile = SDL_FALSE;              // Booléen pour savoir si on a trouvé un event à traiter

    SDL_Event event;

    int x = event.button.x;
    int y = event.button.y;


    while (program_on){

        
        SDL_GetWindowPosition(window1, &x, &y);
        
        const Uint8 *clavier;  

        
        srand(time(NULL));

        if (SDL_PollEvent(&event)){                 // si la file d'évènements n'est pas vide : défiler l'élément en tête      
            
            
                switch(event.type){                       // En fonction de la valeur du type de cet évènement

                    case SDL_QUIT :                           // Un évènement simple, on a cliqué sur la x de la fenêtre
                        program_on = SDL_FALSE;                 // Il est temps d'arrêter le programme
                        break;

                    case SDL_MOUSEBUTTONDOWN :
                        
                        SDL_SetRenderDrawColor(renderer1, 255, 255, 255, 255);
                        SDL_RenderDrawPoint(renderer1, x, y);
                        SDL_RenderPresent(renderer1);     
                        
                        break;

                    case (SDL_KEYDOWN) :

                        SDL_SetRenderDrawColor(renderer1, rand()%256, rand()%256, rand()%256, 255);
                        SDL_RenderClear(renderer1);
                        SDL_RenderPresent(renderer1);

                        SDL_Delay(1);

                        SDL_Keycode key = event.key.keysym.sym;
                        
                        clavier = SDL_GetKeyboardState(NULL);

                        if (key == SDLK_s) {
                            s = true;
                            w = false;
                        } 
                        else if (key == SDLK_w){
                            w = true;
                            s = false;
                        } 
                        else if (key == SDLK_q){
                            q = true;
                            d = false;
                        } 
                        else if (key == SDLK_d){
                            d = true;
                            q = false;
                        } 
                                                
                        
                        
                        else if(clavier[SDL_SCANCODE_ESCAPE]) {
                            program_on = SDL_FALSE;                 // Il est temps d'arrêter le programme
                        }

                        break;


                    

                    //case : 

                    default:                                  // L'évènement défilé ne nous intéresse pas
                        break;
                    }
          
        // Affichages et calculs souvent ici
        }  

        if ((x>x_ecran/4 && (x+x_window)<3*x_ecran/4)&&(y>y_ecran/4 && (y+y_window)<3*y_ecran/4)){
            SDL_SetWindowSize(window1, 99*x_window/100, 99*y_window/100);
            x_window=99*x_window/100;
            y_window=99*y_window/100;
        }



        pas +=0.1;

        if (y>y_ecran-y_window){
            y = 64;
            pas -= 5;
        }
        if (y<y_ecran-mode.h){
            y = y_ecran-y_window;
            pas -= 5;
        }
        if (x<x_ecran-mode.w){
            x = x_ecran-x_window;
            pas -= 5;
        }
        if (x>x_ecran-x_window +1){
            x = 0;
            pas -= 5;
        }


        if (s) {
            y = y+pas;            
        }

        if (w){
                y = y-pas;             
        }

        if (q){
                x = x-pas;             
        }

        if (d) {
            x = x+pas;            
        }
        printf("x = %d, y = %d\n", x, y);
        SDL_SetWindowPosition(window1, x, y);

    }



    //SDL_Delay(100);

    SDL_DestroyWindow(window1);

    SDL_Quit();                                




    return 0;
}