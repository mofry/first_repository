#include <stdio.h>
#include <math.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <stdlib.h>

#include <SDL2/SDL_mixer.h>
#include <stdbool.h>




bool init() {
    //while(true) printf("bite\n");

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        printf("Erreur SDL_Init: %s\n", SDL_GetError());
        return false;
    }
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        printf("Erreur Mix_OpenAudio: %s\n", Mix_GetError());
        return false;
    }
    return true;
}
     /*********************************************************************************************************************/
     /*                              Programme d'exemple de création de rendu + dessin                                    */
     /*********************************************************************************************************************/
     void end_sdl(char ok,                                               // fin normale : ok = 0 ; anormale ok = 1
          char const* msg,                                       // message à afficher
          SDL_Window* window,                                    // fenêtre à fermer
          SDL_Renderer* renderer) {                              // renderer à fermer
       char msg_formated[255];                                            
       int l;                                                     
                                            
       if (!ok) {                                                        // Affichage de ce qui ne va pas
     strncpy(msg_formated, msg, 250);                                         
     l = strlen(msg_formated);                                            
     strcpy(msg_formated + l, " : %s\n");                                     
                                            
     SDL_Log(msg_formated, SDL_GetError());                                   
       }                                                          
                                            
       if (renderer != NULL) {                                           // Destruction si nécessaire du renderer
     SDL_DestroyRenderer(renderer);                                  // Attention : on suppose que les NULL sont maintenus !!
     renderer = NULL;
       }
       if (window != NULL)   {                                           // Destruction si nécessaire de la fenêtre
     SDL_DestroyWindow(window);                                      // Attention : on suppose que les NULL sont maintenus !!
     window= NULL;
       }
                                            
       SDL_Quit();                                                    
                                            
       if (!ok) {                                       // On quitte si cela ne va pas            
     exit(EXIT_FAILURE);                                                  
       }                                                          
     }                                                        
                         
     
void draw_hills(SDL_Renderer* renderer, SDL_Texture* texture,SDL_Window* window, int x, int y, Uint8 alpha) {
  
    
    SDL_Rect source = {0}; 
    SDL_Rect destination = {0};
    SDL_Rect window_dimensions = {0};
    SDL_GetWindowSize(window, &window_dimensions.w,&window_dimensions.h);               // Récupération des dimensions de la fenêtre
    SDL_QueryTexture(texture, NULL, NULL,&source.w, &source.h);  // Récupération des dimensions de l'image
    float zoom = 4;   
  
        destination.w = source.w * zoom;         // La destination est un zoom de la source
        destination.h = source.h * zoom;         // La destination est un zoom de la source
        //destination.x =  (x-window_dimensions.x)%(source.w+window_dimensions.x);     // La destination est au milieu de la largeur de la fenêtre
        destination.y = y;  // La destination est au milieu de la hauteur de la fenêtre
        SDL_SetTextureAlphaMod(texture, alpha);
//        SDL_RenderCopy(renderer, texture,  &source,&destination);   

         // Dessiner la deuxième texture à côté de la première
        destination.x = x + destination.w;

        // Gestion du bouclage de la texture
        if (destination.x > window_dimensions.w) {
            destination.x = destination.x - window_dimensions.w - destination.w;
        }
        SDL_RenderCopy(renderer, texture,  &source,&destination);   
}





 void Fonction_Fond(SDL_Texture* texture, SDL_Window* window, SDL_Renderer* renderer, int x){
    
    SDL_Rect source = {0}; 
    SDL_Rect destination = {0};
    SDL_Rect window_dimensions = {0};
    SDL_GetWindowSize(window, &window_dimensions.w,&window_dimensions.h);               // Récupération des dimensions de la fenêtre
    SDL_QueryTexture(texture, NULL, NULL,&source.w, &source.h);  // Récupération des dimensions de l'image
    float zoom = 4;   
  
        destination.w = source.w * zoom;         // La destination est un zoom de la source
        destination.h = source.h * zoom;         // La destination est un zoom de la source
        destination.x = (x-window_dimensions.x)%(source.w+window_dimensions.x);     // La destination est au milieu de la largeur de la fenêtre
       // -destination.y = y + (window_dimensions.h - destination.h) / 4;  // La destination est au milieu de la hauteur de la fenêtre
        destination.y = 0;
    
        SDL_RenderCopy(renderer, texture,  &source,&destination);   

  }



 void draw_cloud(SDL_Window* window,SDL_Renderer* renderer,SDL_Texture* texture, int x,int y, Uint8 alpha){

    float zoom= 4;
    SDL_Rect source = {0}; 
    SDL_Rect destination = {0};
    SDL_Rect window_dimensions = {0};

    SDL_GetWindowSize(window, &window_dimensions.w,&window_dimensions.h);               // Récupération des dimensions de la fenêtre
    SDL_QueryTexture(texture, NULL, NULL,&source.w, &source.h);  // Récupération des dimensions de l'image
     
    destination=source; 
    destination.y=y;
    destination.x=x;
    destination.h=source.h*zoom;
    destination.w=source.w*zoom;

     SDL_RenderCopy(renderer, texture,  &source,&destination);

     

 }







  void Fonction_Affichage_perso(SDL_Texture* my_texture, SDL_Window* window, SDL_Renderer* renderer, int frame) {
    SDL_Rect source = {0}, window_dimensions = {0}, destination = {0}, state = {0};

    SDL_GetWindowSize(window, &window_dimensions.w, &window_dimensions.h);
    SDL_QueryTexture(my_texture, NULL, NULL, &source.w, &source.h);

    int nb_images = 6;
    float zoom = 5;
    int offset_x = source.w / nb_images;
    int offset_y = source.h;

    state.x = frame * offset_x;
    state.y = 0;
    state.w = offset_x;
    state.h = offset_y;

    destination.w = offset_x * zoom;
    destination.h = offset_y * zoom;
    destination.x = (window_dimensions.w - destination.w)/2;
    destination.y = 5 * (window_dimensions.h - destination.h) / 6;

    SDL_RenderCopy(renderer, my_texture, &state, &destination);
}


void afficher_texte(TTF_Font* font, SDL_Renderer* renderer) {
    SDL_Color color = {255,0,0, 255}; // Blanc
    SDL_Surface* surface = TTF_RenderText_Blended(font, "LUMBERJACK", color);
    if (!surface) {
        printf("Erreur TTF_RenderText_Blended : %s\n", TTF_GetError());
        return;
    }

    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!texture) {
        printf("Erreur SDL_CreateTextureFromSurface : %s\n", SDL_GetError());
        SDL_FreeSurface(surface);
        return;
    }

    SDL_DisplayMode screen;
    SDL_GetCurrentDisplayMode(0, &screen);

    SDL_Rect rect;
    rect.w = surface->w;
    rect.h = surface->h;
    rect.x = (screen.w - rect.w) / 2;
    rect.y = screen.h / 4;

    //SDL_FreeSurface(surface);  // on peut libérer la surface après la création de la texture

    SDL_RenderCopy(renderer, texture, NULL, &rect);
    SDL_DestroyTexture(texture); // on détruit la texture après affichage
}


void affichage_menu(SDL_Window* window,SDL_Renderer* renderer,SDL_Texture* texture, int x,int y, Uint8 alpha){

    float zoom= 0.2;
    SDL_Rect source = {0}; 
    SDL_Rect destination = {0};
    SDL_Rect window_dimensions = {0};

    SDL_GetWindowSize(window, &window_dimensions.w,&window_dimensions.h);               // Récupération des dimensions de la fenêtre
    SDL_QueryTexture(texture, NULL, NULL,&source.w, &source.h);  // Récupération des dimensions de l'image
     
    destination=source; 
    destination.y=y;
    destination.x=x;
    destination.h=source.h*zoom;
    destination.w=source.w*zoom;

     SDL_RenderCopy(renderer, texture,  &source,&destination);

     

 }



     

     int main(int argc, char** argv) {
       (void)argc;
       (void)argv;

      if(!init()){
        return 1;
      }

    Mix_Music *music = NULL;
    Mix_Chunk* cri_bucheron=NULL; 
    Mix_Chunk* woosh=NULL;

       //Gestion son
        if (TTF_Init() == -1) {
         printf("Erreur SDL_ttf : %s\n", TTF_GetError());
        exit(1);
        }
        //gestion texte
        TTF_Font* font = TTF_OpenFont("/home/mofry/Morrel/ProjetZZ1/Travail_groupe/menu_sdl2/sprites/Mitchell Demo.otf", 48); // 48 = taille
        if (!font) {
            printf("Erreur chargement font : %s\n", TTF_GetError());
            exit(1);
        }

       
        SDL_Surface* surface=NULL;
        SDL_Renderer* renderer_text=NULL;
        SDL_Window* window_text=NULL;

        





       music=Mix_LoadMUS("/home/mofry/Morrel/ProjetZZ1/Travail_groupe/menu_sdl2/sprites/effets_sonores/midnight-forest-184304.ogg");
       cri_bucheron=Mix_LoadWAV("/home/mofry/Morrel/ProjetZZ1/Travail_groupe/menu_sdl2/sprites/effets_sonores/cri_bucheron.wav");
       woosh=Mix_LoadWAV("/home/mofry/Morrel/ProjetZZ1/Travail_groupe/menu_sdl2/sprites/effets_sonores/woosh.wav");


       SDL_Window* window = NULL;
       SDL_Renderer* renderer = NULL;

       SDL_DisplayMode screen;
       SDL_bool program_on = SDL_TRUE;               
       SDL_Event event; 

        

       /*********************************************************************************************************************/  
       /*                         Initialisation de la SDL  + gestion de l'échec possible                                   */

       if (SDL_Init(SDL_INIT_VIDEO) != 0) end_sdl(0, "ERROR SDL INIT", window, renderer);

       SDL_Texture* hill;

       SDL_GetCurrentDisplayMode(0, &screen);
       printf("Résolution écran\n\tw : %d\n\th : %d\n", screen.w, screen.h);
    
       
       window = SDL_CreateWindow("Premier dessin", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, screen.w, screen.h, SDL_WINDOW_OPENGL);
       if (window == NULL) end_sdl(0, "ERROR WINDOW CREATION", window, renderer);

       
       renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
       if (renderer == NULL) end_sdl(0, "ERROR RENDERER CREATION", window, renderer);

       hill = IMG_LoadTexture(renderer,"./colline.png");   

        if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
            end_sdl(0, "IMG_Init PNG", window, renderer);
        }




        /*renderer_text= SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
       if (renderer_text == NULL) end_sdl(0, "ERROR RENDERER CREATION", window_text, renderer_text);*/


        

        
        SDL_Texture* texture_marche = IMG_LoadTexture(renderer, "sprite_perso/1_Woodcutter/Woodcutter_walk.png");
        if (texture_marche == NULL) end_sdl(0, "IMG_LoadTexture", window, renderer);

        SDL_Texture* fond_texture = IMG_LoadTexture(renderer, "nature4.png");
        if (fond_texture == NULL) end_sdl(0, "IMG_LoadTexture", window, renderer);

        SDL_Texture* texture_attaque = IMG_LoadTexture(renderer, "sprite_perso/1_Woodcutter/Woodcutter_attack1.png");
        if (texture_attaque == NULL) end_sdl(0, "IMG_LoadTexture", window, renderer);

        SDL_Texture* cloud =IMG_LoadTexture(renderer,"/home/mofry/Morrel/ProjetZZ1/Travail_groupe/menu_sdl2/sprites_a_utiliser/nuages.png");
        SDL_Texture* menu =IMG_LoadTexture(renderer,"/home/mofry/Morrel/ProjetZZ1/Travail_groupe/menu_sdl2/sprites/menu_sprite.png");


        
    
        int zoom=4;
        SDL_Rect source={0},destination={0};
        SDL_QueryTexture(cloud,NULL,NULL,&source.w,&source.h);
         destination.h=source.h*zoom;
         destination.w=source.w*zoom;
        int x, y;
        x = 0;
        y = 0;
        bool attaque = false;

        int frame_marche = 0;
        int frame_attaque = 0;
        int nb_frames_marche = 6;
        int nb_frames_attaque = 6; 
        int x1, x2;
        x1 = 100; x2 = 0;

        int cloud_x1=0, cloud_x2=destination.w;
        int cloud_speed1=1,cloud_speed2=2;

        int alpha1 = 50; 
        int alpha2 = 250;
        int speed1 = 2;
        int speed2 = 4;
        int y1 = 30, y2=250;

        Uint32 last_time = SDL_GetTicks();
        Uint32 current_time;
        const Uint32 frame_duration = 100; 
        Mix_PlayMusic(music, -1);

        int menu_width, menu_height;
    SDL_QueryTexture(menu, NULL, NULL, &menu_width, &menu_height);
    menu_width *= 0.5;
    menu_height *= 0.5;

    int menu_x = screen.w - menu_width + 400;
    int menu_y = screen.h - menu_height  ;

        while (program_on) {

           
            
            while (SDL_PollEvent(&event)) { 
                switch(event.type) {
                    case SDL_QUIT:
                        program_on = SDL_FALSE;
                        break;
                    case SDL_KEYDOWN:
                        if (event.key.keysym.sym == SDLK_ESCAPE)
                            program_on = SDL_FALSE;
                        if (event.key.keysym.sym == SDLK_SPACE)
                            attaque = true;
                            Mix_PlayChannel(-1,cri_bucheron,0);
                            Mix_PlayChannel(-1,woosh,0);
                        break;
                    case SDL_KEYUP:
                        if (event.key.keysym.sym == SDLK_SPACE)
                            attaque = false;
                        break;
                }
            }


            current_time = SDL_GetTicks();
            if (current_time - last_time >= frame_duration) {
                last_time = current_time;
                if (attaque)
                    frame_attaque = (frame_attaque + 1) % nb_frames_attaque;
                else
                    frame_marche = (frame_marche + 1) % nb_frames_marche;
            }

    
            SDL_RenderClear(renderer);
            
            draw_cloud(window,renderer,cloud,cloud_x1,0,180);
            draw_cloud(window,renderer,cloud,cloud_x2,0,100);
            affichage_menu(window,renderer,menu,menu_x,500,100);
           // afficher_texte(font,renderer_text);
            //draw_cloud(window,renderer,cloud,0,0,200);
            //draw_hills(renderer, hill, window, x2, y2, alpha2);
            //draw_hills(renderer, hill, window, x1, y1, alpha1);
            

            Fonction_Fond(fond_texture, window, renderer, x);
            if (attaque)
                Fonction_Affichage_perso(texture_attaque, window, renderer, frame_attaque);
            else
                Fonction_Affichage_perso(texture_marche, window, renderer, frame_marche);
            SDL_RenderPresent(renderer);
            
            SDL_SetRenderDrawColor(renderer, 173, 216, 230, 255); //n'est plus utile//SDL_RenderClear(renderer); // efface tout en le remplissant de cette couleur


            x = (x - 4) % screen.w;
            x1 = (x1 - speed1) % screen.w;
            x2 = (x2 - speed2) % screen.w;


           

            cloud_x1 -= cloud_speed1;
            cloud_x2 -= cloud_speed2;

            if (cloud_x1 < -destination.w/2) cloud_x1 = screen.w;
            draw_cloud(window,renderer,cloud,cloud_x1,0,180);
            if (cloud_x2 < -destination.w) cloud_x2 = screen.w;

            SDL_Delay(16);
        }


        
        SDL_DestroyTexture(texture_marche);
        SDL_DestroyTexture(texture_attaque);
        SDL_DestroyTexture(fond_texture);


       /*********************************************************************************************************************/
       /*                                     On dessine dans le renderer                                                   */
       /*********************************************************************************************************************/
       /*             Cette partie pourrait avantageusement être remplacée par la boucle évènementielle                     */ 
       //draw(renderer);                                      // appel de la fonction qui crée l'image  
       SDL_RenderPresent(renderer);                         // affichage
       //SDL_Delay(1000);                                     // Pause exprimée en ms
                                                       

       /* on referme proprement la SDL */
       end_sdl(1, "Normal ending", window, renderer);
       return EXIT_SUCCESS;
     }