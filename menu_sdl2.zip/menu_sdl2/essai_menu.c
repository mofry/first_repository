#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <math.h>

#define M_PI 3.14159265358979323846

#include <stdio.h>
#include <string.h>


//afficher forêt

void end_sdl(char ok,                                               // fin normale : ok = 0 ; anormale ok = 1
          char const* msg,                                       // message à afficher
          SDL_Window* window,                                    // fenêtre à fermer
          SDL_Renderer* renderer) {                              // renderer à fermer
       char msg_formated[255];
       int l;

       if (!ok) {                                                        // Affichage de ce qui ne va pas
     strncpy(msg_formated, msg, 250);
     l = strlen(msg_formated);
     strcpy(msg_formated + l, " : %s\n");

     SDL_Log(msg_formated, SDL_GetError());
       }

       if (renderer != NULL) {                                           // Destruction si nécessaire du renderer
     SDL_DestroyRenderer(renderer);                                  // Attention : on suppose que les NULL sont maintenus !!
     renderer = NULL;
       }
       if (window != NULL)   {                                           // Destruction si nécessaire de la fenêtre
     SDL_DestroyWindow(window);                                      // Attention : on suppose que les NULL sont maintenus !!
     window= NULL;
       }

       SDL_Quit();

       if (!ok) {                                       // On quitte si cela ne va pas
     exit(EXIT_FAILURE);
       }
}

/*
void draw_forest(SDL_Window* window,SDL_Renderer* renderer, SDL_Texture* texture, int x, int y, Uint8 alpha){
    float zoom=0.5;
    SDL_Rect 
        source={0},
        destination={0},
        window_dimensions={0};
    
    SDL_GetWindowSize(window, &window_dimensions.w, &window_dimensions.h);
    SDL_QueryTexture(texture, NULL, NULL, &source.w, &source.h);

    destination=source;
    //destination.y=(window_dimensions.h-source.h)*zoom;

    SDL_RenderCopy(renderer, texture, &source, &destination);


}*/

void draw_forest(SDL_Window* window, SDL_Renderer* renderer, SDL_Texture* texture, int x, int y, Uint8 alpha) {
    SDL_Rect source = {0}, destination = {0};
    int img_w, img_h, win_w, win_h;
    float scale;

    SDL_GetWindowSize(window, &win_w, &win_h);
    SDL_QueryTexture(texture, NULL, NULL, &img_w, &img_h);

    // Calcul du facteur de réduction pour que l'image rentre dans la fenêtre
    float scale_x = (float)win_w / img_w;
    float scale_y = (float)win_h / img_h;
    scale = fminf(scale_x, scale_y); // on prend le plus petit pour que ça tienne

    destination.w = img_w * scale;
    destination.h = img_h * scale;
    destination.x = (win_w - destination.w) / 2;
    destination.y = (win_h - destination.h) / 2;

    SDL_SetTextureAlphaMod(texture, alpha);
    SDL_RenderCopy(renderer, texture, NULL, &destination);
}


void draw_sky(SDL_Window* window, SDL_Renderer* renderer, SDL_Texture* texture, int x, int y, Uint8 alpha){

     SDL_Rect source = {0}, destination = {0}, window_dimensions={0};
     

    SDL_GetWindowSize(window, &window_dimensions.w, &window_dimensions.h);
    SDL_QueryTexture(texture, NULL, NULL, &source.w, &source.h);
    destination=source;

    SDL_SetTextureAlphaMod(texture, alpha);
    SDL_RenderCopy(renderer, texture, NULL, &destination);




}



  




int main(){
    //initialisation fen,rendu et texture 
    SDL_Window* window=NULL;
    SDL_Renderer* renderer=NULL;
    SDL_Texture* forest=NULL;
    SDL_Texture* sky=NULL;


    //Initialisation pour evenements
    SDL_Event event;
    SDL_bool en_cours=SDL_TRUE;

    // Initialisation de la SDL
    SDL_Init(SDL_INIT_VIDEO); 
    window = SDL_CreateWindow("ProjetZZ1", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1000, 1100, SDL_WINDOW_SHOWN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    //textures
    forest=IMG_LoadTexture(renderer,"/home/mofry/Morrel/ProjetZZ1/Travail_groupe/menu_sdl2/sprites_a_utiliser/forest3.jpg");
    if (!forest) end_sdl(1,"probleme_de_texture",window,renderer);
    sky=IMG_LoadTexture(renderer,"/home/mofry/Morrel/ProjetZZ1/Travail_groupe/menu_sdl2/sprites_a_utiliser/ciel.png");
    if (!forest) end_sdl(1,"probleme_de_texture_sky",window,renderer);
    

    SDL_RenderPresent(renderer);

    //Boucle des evenements
    while(en_cours){

        while(SDL_PollEvent((&event))){
            if(event.type==SDL_QUIT){
                en_cours=SDL_FALSE;
            }
        }
        SDL_RenderClear(renderer);
        
        draw_forest(window,renderer,forest,0,0,255);
        draw_sky(window,renderer,sky,0,0,200);
        SDL_RenderPresent(renderer);
    }


    end_sdl(0,"fermeture",window,renderer);
    SDL_DestroyTexture(forest);
    return 0;
}